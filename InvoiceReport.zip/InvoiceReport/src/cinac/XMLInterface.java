package cinac;

import java.util.List;

public interface XMLInterface {

	void xmlConverter();
	
}
