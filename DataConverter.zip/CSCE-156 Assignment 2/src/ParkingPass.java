
public class ParkingPass extends Product{
	
	public ParkingPass(String productCode, String productType, double unitPrice) {
		super(productCode, productType, unitPrice);
	}

	
}
